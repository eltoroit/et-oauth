import cHomeBundle from "c/home";
import { createElement } from "lwc";

const cHomeLWC = createElement("c-home", { is: cHomeBundle });
const dest = document.querySelector("#main");
dest.appendChild(cHomeLWC);
