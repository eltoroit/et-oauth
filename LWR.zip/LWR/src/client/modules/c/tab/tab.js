import { api } from "lwc";
import loadSLDS from "c/loadSLDS";

export default class Tab extends loadSLDS {
    @api label;
    @api tabClass;
    @api isHidden;

    get classHidden() {
        return `${this.tabClass} ${this.isHidden ? "slds-hide" : ""}`;
    }
}
