// Solution adjusted from here:
// https://salesforce.stackexchange.com/questions/371650/how-to-use-lightning-design-system-in-lwr/373962#373962

import { LightningElement } from "lwc";

export default class LoadSLDS extends LightningElement {
    constructor() {
        super();
        this.loadCss(this);
    }

    loadCss(cmp, path = "/SLDS/styles/salesforce-lightning-design-system.css") {
        return new Promise((resolve) => {
            const style = document.createElement("link");
            style.href = path;
            style.rel = "stylesheet";

            style.onload = () => {
                resolve(style);
            };
            style.onerror = (e) => {
                console.error("Unable to load", path, e);
            };

            if (cmp) {
                cmp.template.appendChild(style);
            } else {
                document.querySelector("head").appendChild(style);
            }
        });
    }
}
