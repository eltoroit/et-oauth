import lwc from "@lwc/rollup-plugin";
import copy from "rollup-plugin-copy";
import replace from "@rollup/plugin-replace";
import { nodeResolve } from "@rollup/plugin-node-resolve";

export default {
    input: "src/client/index.js",

    output: {
        dir: "dist/lwc",
        format: "esm"
    },

    plugins: [
        replace({
            preventAssignment: true,
            "process.env.NODE_ENV": JSON.stringify("development")
        }),
        nodeResolve(),
        lwc(),
        copy({
            targets: [
                { src: "src/client/resources/", dest: "dist" },
                { src: "src/client/index.html", dest: "dist" },
                { src: "node_modules/@salesforce-ux/design-system/assets", dest: "dist", rename: "SLDS" }
            ]
        })
    ]
};
